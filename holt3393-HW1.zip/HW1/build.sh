#! /bin/bash

gcc part1.c
cd arithmetic
gcc arith_loop.c
cd ..
cd IO
gcc file_loop.c
cd ..
